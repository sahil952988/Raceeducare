import { NavLink } from "react-router-dom"


const Header = () => {
  return (
    <>
      <div className="all_items">
        <div className="  ">
          <p className=' topheading sm:text-[40px] text-center text-[20px] ml-5
       text-white  mt-10 font-semibold '>Study In Ireland By Race Educare</p>
        </div>
      </div >
    </>
  )
}
export default Header